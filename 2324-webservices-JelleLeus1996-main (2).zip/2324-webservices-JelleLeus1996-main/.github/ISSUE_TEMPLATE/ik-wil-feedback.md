---
name: Ik wil feedback
about: Vraag feedback op jouw code
title: ''
labels: ''
assignees: ksa607, thomasaelbrecht

---

> Zorg ervoor dat enkel jouw docent bij de assignees staat

Ik wens feedback:

* Maak een lijstje van vragen waarop je zeker een antwoord wil
* Zonder concrete vragen is het moeilijk om feedback te geven
