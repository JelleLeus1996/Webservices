---
name: Ik heb een probleem
about: Vraag onze hulp bij een probleem
title: ''
labels: ''
assignees: ksa607, thomasaelbrecht

---

> Zorg ervoor dat enkel jouw docent bij de assignees staat

**Beschrijving**
Beschrijf duidelijk en beknopt wat het probleem precies is.

**Probleem reproduceren**
Stappen om het probleem te reproduceren:

1. Start de server d.m.v. de instructies in de README
2. Voer een POST uit op '...'
3. See error

**Verwacht gedrag**
Een duidelijke en beknopte beschrijving van wat je verwacht dat ze zou gebeuren (als het goed gaat).

**Screenshots**
Indien nodig, voeg screenshots, een GIF of een video toe om het probleem te demonstreren.

**Extra context**
Indien nodig, voeg hier extra context toe die nodig is om de applicatie/het probleem te begrijpen.
