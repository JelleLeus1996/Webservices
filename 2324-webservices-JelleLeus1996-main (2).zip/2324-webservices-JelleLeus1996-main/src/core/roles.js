module.exports = Object.freeze({
  TEAMREPRESENTATIVE: 'teamrepresentative',
  ADMIN: 'admin',
});
