const Router = require('@koa/router');
const Joi = require('joi').extend(require('@joi/date'));

const riderService = require('../service/rider');
const validate = require('../core/validation');
const {requireAuthentication, makeRequireRole} = require('../core/auth');
const Role = require('../core/roles');


//Verification team via paramater
const checkTeamId = (ctx, next) => {
  
  const { team_id:paramTeamId } = ctx.params;

  // You can only get our own data unless you're an admin
  checkTeam(ctx, paramTeamId);
  return next();
};

//Verification team via session id or role
const checkTeam = (ctx, teamId)=>{
  const { teamId:sessionTeamId, roles } = ctx.state.session;
  if (teamId !== sessionTeamId && !roles.includes(Role.ADMIN)) {
    return ctx.throw(
      403,
      'You are not allowed to view this user\'s information',
      {
        code: 'FORBIDDEN',
      }
    );
  }
};

//Verification via paramater of rider to get teamId
const checkTeamIdViaRider = async (ctx, next) => {
  const { id } = ctx.params;
  const rider = await riderService.getById(Number(id));
  checkTeam(ctx, rider.team_id);
  return next();
};

//GET all riders
const getRiders = async (ctx) => {
  ctx.body = await riderService.getAll();
};
const getAllRidersInfo = async (ctx) => {
  ctx.body = await riderService.getAllRidersInfo();
};

//GET all riders with team info
const getAllRidersWithTeam = async (ctx) =>
{
  ctx.body = await riderService.getAllWithTeam();
};

//No input, so no validations of input
getRiders.validationScheme = null;
getAllRidersInfo.validationScheme = null;
getAllRidersWithTeam.validationScheme = null;

//GET individual rider (by id)
const getRiderById = async (ctx) => {
  ctx.body = await riderService.getById(Number(ctx.params.id));
};

//Validation of the paramater id
getRiderById.validationScheme = {
  params: Joi.object({
    id: Joi.number().integer().positive().required()
  })
};

//GET individual rider (by full name)
const getRiderByFullName = async (ctx) => {
  ctx.body = await riderService.getRiderByFullName(
    String(ctx.params.first_name),
    String(ctx.params.last_name));
};

//Validation of the paramaters first & last name
getRiderByFullName.validationScheme = {
  params: Joi.object({
    last_name: Joi.string().min(1).max(50).required(),
    first_name: Joi.string().min(1).max(50).required(),
  })
};

//GET individual team (by id)
const getRidersFromTeam = async (ctx) => {
  ctx.body = await riderService.getRidersFromTeam(Number(ctx.params.team_id));
};

//Validation of the paramater id
getRidersFromTeam.validationScheme={
  params: Joi.object({
    team_id: Joi.number().integer().positive().required()
  })
};



//UPDATE rider
const updateRider = async (ctx) => {
  ctx.body = await riderService.updateById(Number(ctx.params.id), {
    ...ctx.request.body,
    nationality: String(ctx.request.body.nationality),
    last_name: String(ctx.request.body.last_name),
    first_name: String(ctx.request.body.first_name),
    birthday: new Date(ctx.request.body.birthday),
    points: Number(ctx.request.body.points),
    team_id: ctx.state.session.teamId,
    monthly_wage: Number(ctx.request.body.monthly_wage),  
  });
};

//Validation of the paramater id & the given rider info
updateRider.validationScheme={
  params: Joi.object({
    id: Joi.number().integer().positive().required()
  }),
  body:{
    nationality: Joi.string().min(1).max(50).required(),
    last_name: Joi.string().min(1).max(50).required(),
    first_name: Joi.string().min(1).max(50).required(),
    team_id: Joi.number().integer().required(),
    birthday: Joi.date().greater('1-1-1970').required(),
    points: Joi.number().min(0).max(1000000),
    monthly_wage: Joi.number().min(0).max(1000000),
  }
};

//POST rider
const createRider = async (ctx) => {
  const newRider = await riderService.create({
    ...ctx.request.body,
    nationality: String(ctx.request.body.nationality),
    last_name: String(ctx.request.body.last_name),
    first_name: String(ctx.request.body.first_name),
    birthday: new Date(ctx.request.body.birthday),
    points: Number(ctx.request.body.points),
    team_id: ctx.state.session.team_id,
    monthly_wage: Number(ctx.request.body.monthly_wage),  
  });
  ctx.body = newRider;
};

//Validation of the given rider info
createRider.validationScheme={
  body:{
    id: Joi.number().integer().required(),
    nationality: Joi.string().min(1).max(50).required(),
    last_name: Joi.string().min(1).max(50).required(),
    first_name: Joi.string().min(1).max(50).required(),
    birthday: Joi.date().greater('1-1-1970').required(),
    points: Joi.number().min(0).max(1000000),
    monthly_wage: Joi.number().min(0).max(1000000),
  }
};

//DELETE rider
const deleteRider = async (ctx) => {
  await riderService.deleteById(Number(ctx.params.id));
  ctx.status = 204;
};

//Validation of the paramater id
deleteRider.validationScheme = {
  params: Joi.object({
    id: Joi.number().integer().positive().required()
  })
};

/**
 * Install riders routes in the given router.
 *
 * @param {Router} app - The parent router.
 */
module.exports = (app) => {//created nested route
  const router = new Router({
    prefix: '/riders',
  });

  //Variable assigned for admin required requests
  const requireAdmin = makeRequireRole(Role.ADMIN);

  //GET
  router.get('/', requireAuthentication, validate(getRiders), getRiders);
  router.get('/allInfo', requireAuthentication, validate(getAllRidersInfo), checkTeamId, getAllRidersInfo);
  router.get('/all/getAllRidersWithTeam', requireAuthentication, validate(getAllRidersWithTeam.validationScheme),getAllRidersWithTeam);
  router.get('/full-name/:first_name/:last_name', requireAuthentication, validate(getRiderByFullName.validationScheme), checkTeamId, getRiderByFullName);
  router.get('/:id', requireAuthentication, validate(getRiderById.validationScheme),checkTeamIdViaRider, getRiderById);
  router.get('/team/:team_id', requireAuthentication, validate(getRidersFromTeam.validationScheme),checkTeamId, getRidersFromTeam);

  //POST
  router.post('/', requireAuthentication,requireAdmin, validate(createRider.validationScheme), createRider);

  //UPDATE (PUT)
  router.put('/:id',requireAuthentication, validate(updateRider.validationScheme),checkTeamIdViaRider, updateRider);

  //DELETE
  router.delete('/:id',requireAuthentication, requireAdmin, validate(deleteRider.validationScheme), deleteRider);
  
  app.use(router.routes())
    .use(router.allowedMethods());
};
/*
JSON Login for admin
{
  "email":"jelle.leus@student.hogent.be",
  "password":"12345678"
}
JSON Login for non-admin - team 5
{
  "email":"Hendrik.Redant@hotmail.com",
  "password":"12345678"
}
*/
